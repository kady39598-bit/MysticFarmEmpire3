extends Node
var save_path = "user://save.json"
func salvar():
    var data = {"dinheiro": GameManager.dinheiro, "nivel": GameManager.nivel}
    var file = FileAccess.open(save_path, FileAccess.WRITE)
    file.store_string(JSON.stringify(data))
