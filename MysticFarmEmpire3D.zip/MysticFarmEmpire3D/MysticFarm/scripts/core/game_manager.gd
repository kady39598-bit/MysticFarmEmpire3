extends Node
var dinheiro = 1000
var xp = 0
var nivel = 1
func adicionar_dinheiro(v): dinheiro += v
func gastar_dinheiro(v):
    if dinheiro >= v:
        dinheiro -= v
        return true
    return false
