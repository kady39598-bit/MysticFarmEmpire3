extends CanvasLayer
func _process(delta):
    $Panel/Dinheiro.text = str(GameManager.dinheiro)
