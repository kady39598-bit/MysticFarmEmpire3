extends Control
func _on_comprar_pressed():
    GameManager.gastar_dinheiro(100)
